var base_url = 'http://192.168.1.8';

chrome.webNavigation.onCommitted.addListener(function (e) {
        $.ajax({
            async: false,
            cache: false,
            url: base_url+'/api/v1/shops/extension?url=' + e.url,
            type: 'get',
            success: function (data, status) {
                console.log(data);
                if (data.corp_status == '吊销') {
                    chrome.pageAction.setPopup({tabId: e.tabId, popup: 'popup_black.html'});
                    chrome.pageAction.setTitle({tabId: e.tabId, title: '此网店在黑名单中'});
                    chrome.pageAction.show(e.tabId);
                } else if (data.el_info) {
                    chrome.pageAction.setPopup({tabId: e.tabId, popup: 'popup_gray.html'});
                    chrome.pageAction.setTitle({tabId: e.tabId, title: '此网店在灰名单中'});
                    chrome.pageAction.show(e.tabId);
                }
            },
            error: function (error) {

            }
        });
    },
    {
        url: [
            {urlContains: 'jd.com'},
            {urlContains: 'paipai.com'}
        ]
    }
);