function init() {
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, function (tabs) {
            $.ajax({
                async: false,
                cache: false,
                url: 'http://192.168.1.8/api/v1/shops/extension?url=' + tabs[0].url,
                type: 'get',
                success: function (data, status) {
                    console.log(data);
                    $('#shop_name').text(data.main_info.shop_name);
                    $('#corp_name').text(data.main_info.corp_name);
                    $('#register_num').text(data.main_info.register_num);
                },
                error: function (error) {

                }
            });
        });
    }
$(document).ready(
    function () {
        init();
    }
);
