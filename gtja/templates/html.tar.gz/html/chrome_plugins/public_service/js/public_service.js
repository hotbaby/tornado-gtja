function init() {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        var url = tabs[0].url;
        console.log(url);
        $.ajax({
            cache: false,
            url: "http://192.168.1.8/api/v1/public?url=" + url,
            type: 'get',
            success: function (data, status) {
                console.log(data);
                console.log(status);
                $('#register_num').text(data.register_num);
                $('#corp_name').text(data.corp_name);
                $('#licence').text(data.licence ? "有" : "否");
                $('#jurisdictional_agency').text(data.jurisdictional_agency);
                $('#jurisdictional_people').text(data.jurisdictional_people);
            },
            error: function (error) {

            }
        });
    });
}

function urlencode(str) {
    str = (str + '').toString();
    return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').
        replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');
}

$(document).ready(
    function () {
        init();
    }
);
