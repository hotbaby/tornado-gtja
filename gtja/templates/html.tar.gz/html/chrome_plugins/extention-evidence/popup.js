$(document).ready(function (){
	$('#start_btn').on('click', function(){
		chrome.cookies.get({url:'http://192.168.1.8', name : 'session'}, function(cookie){
			if (cookie){
				var evi_name = $('#evidences_name').val();
				var evi_desc = $('#evidences_desc').val();
				var evi_id   = $('#evidences_id').val();

				if ((evi_name == "") || (evi_desc == "") || (evi_id == "")){
					alert("请输入证据信息");
					return;
				}

				chrome.runtime.sendMessage({
					btn_event: "start",
					evi_name : $('#evidences_name').val(),
					evi_desc : $('#evidences_desc').val(),
					evi_id   : $('#evidences_id').val()
    			});
			}else{
				alert("用户未登录");
			}
		});
	});

	$('#stop_btn').on('click', function(){
		chrome.runtime.sendMessage({
      			btn_event: "stop"
    		});		
	});

	chrome.runtime.sendMessage({popup:'popup'}, function(resp){
		console.log(resp);
		$('#evidences_name').val(resp.evi_name);
	 	$('#evidences_desc').val(resp.evi_desc);
      		$('#evidences_id').val(resp.evi_id);
	});
});
	




