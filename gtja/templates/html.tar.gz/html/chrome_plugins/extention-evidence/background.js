var captureParameter = {
	audio : false,
	video : true,
	videoConstraints : {
		mandatory: {
			chromeMediaSource: 'tab',
			maxWidth : 1280,
			maxHeight: 720,
			minFrameRate : 15,
			maxFrameRate : 30,
			minAspectRatio: 1.77,
			googLeakyBucket: true,
			googTemporalLayeredScreencast: true
		}
	}
};

var tabStream;
var mediaRecorder;
var base_url = 'http://192.168.1.8';
var evi_name,evi_desc,evi_id;
var g_status = 'stop';
var evi_name = "";
var evi_desc = "";
var evi_id   = "";

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse){
		if(request.popup == "popup"){
			sendResponse({evi_name : evi_name, evi_desc : evi_desc, evi_id : evi_id});
		}
	 	if ((request.btn_event == "start") && (g_status == 'stop')){
			g_status = 'start';
			evi_name = request.evi_name;
			evi_desc = request.evi_desc;
			evi_id   = request.evi_id;
			chrome.tabCapture.capture(captureParameter, function(mediaStream){
				tabStream = mediaStream;
				mediaRecorder = new MediaStreamRecorder(tabStream);
				console.log(mediaRecorder);
				mediaRecorder.mimeType = 'video/webm';
				mediaRecorder.width = 1280;
				mediaRecorder.height = 720;
				mediaRecorder.ondataavailable = function (blob) {
						if (blob){
							var videofile = {body:blob, content_type:'video/webm', filename: 'evidence.webm'};
							var formData = new FormData();
							formData.append("filetype",'evidence'); 
							formData.append("comment",'evidence video');
							formData.append("name",'evidence.webm');
							formData.append("content_type",'video/webm');
							formData.append("body",blob);
							console.log(formData);
							var name = evi_name;
							var desc = evi_desc;
							var id   = evi_id;
							console.log(evi_name, evi_desc, evi_id);
							$.ajax({
            					cache: false,
            					url: base_url + '/api/v1/file',
            					type: 'post',
								data: formData,
								processData: false,
								contentType: false,
            					success: function (data, status){
									console.log(data);
									var createEviInfo = {
										id   : id,
										fid  : data._id,
										name : name,
										type : 'online-video',
										other: desc
									};
									$.ajax({
            							cache: false,
            							url: base_url + '/api/v1/evidences',
            							type: 'post',
										data: JSON.stringify(createEviInfo),
            							success: function (data, status){
											console.log(data);	
										},	
            							error: function (error) {
            							}
									});
            					},
            					error: function (error) {
            					}
        					});
						}
					};
				mediaRecorder.start(500000);
			});
		}

    	if ((request.btn_event == "stop") && (g_status == 'start')) {
			g_status = 'stop';
			if (mediaRecorder){
    			mediaRecorder.stop();
			}
			if (tabStream){
				tabStream.stop();
			}
			
			evi_name = "";
			evi_desc = "";
			evi_id   = "";
		}
	});
