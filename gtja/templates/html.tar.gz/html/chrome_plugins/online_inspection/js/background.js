var base_url = 'http://192.168.1.8/api/v1';

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.event == "saveClue") {
            var data = {
                'source': request.source,
                'info': request.info,
                'content': request.content,
                'url': request.url,
                'law': request.law,
                'other': request.other
            };

            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + "/clues", 'UTF-8'),
                type: 'post',
                data: JSON.stringify(data),
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }
        if (request.event == "getUserInfo") {
            $.ajax({
                async: false,
                cache: false,
                url: encodeURI(base_url + '/user/detail', 'UTF-8'),
                type: 'get',
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "getUsersByDepartment") {
            $.ajax({
                async: false,
                cache: false,
                url: encodeURI(base_url + '/user/help?region=' + request.region, 'UTF-8'),
                type: 'get',
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "handleClue") {
            var data = {
                'wf_name': request.wf_name,
                'action': request.action,
                'to_user': request.to_user,
                'data': {
                    'clue_id': request.clue_id
                }
            };
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + "/workflows"),
                type: 'post',
                data: JSON.stringify(data),
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "initShop") {
            var url = request.url;
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/shops/extension?url=' + url, 'UTF-8'),
                type: 'get',
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "getAllTags") {
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/tags/all', 'UTF-8'),
                type: 'get',
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "getTags") {
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/tags', 'UTF-8'),
                type: 'get',
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "createTag") {
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/tags', 'UTF-8'),
                type: 'post',
                data: JSON.stringify({
                    "name": request.tagName,
                    "description": '',
                    "original_url": request.url
                }),
                success: function (resp) {
                    resp.status = true;
                    sendResponse(resp);
                },
                error: function (resp) {
                    resp.status = false;
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "saveTag") {
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/shops/' + request.type + '/' + request.id, 'UTF-8'),
                type: 'patch',
                data: JSON.stringify(request.data),
                success: function (resp) {
                    resp.status = true;
                    sendResponse(resp);
                },
                error: function (resp) {
                    resp.status = false;
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "commitTag") {
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/tag_lib', 'UTF-8'),
                type: 'post',
                data: JSON.stringify(request.data),
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }

        if (request.event == "finishTask") {
            $.ajax({
                cache: false,
                async: false,
                url: encodeURI(base_url + '/shops/extension/tasks/' + request.id, 'UTF-8'),
                data: JSON.stringify(request.data),
                type: 'patch',
                success: function (resp) {
                    sendResponse(resp);
                },
                error: function (resp) {
                    sendResponse(resp);
                }
            });
        }
    }
);
