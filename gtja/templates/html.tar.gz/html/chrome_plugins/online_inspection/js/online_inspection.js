var shopInfo = {};
var content = [];

function init() {
    // 线索相关
    $('#btn_create_clue').click(function () {
        $('#shop_info').hide();
        $('#clue_info').show();
        initClue();
    });
    $('#btn_save_clue').click(function () {
        $('#shop_info').show();
        $('#clue_info').hide();
        saveClue();
    });
    $('#btn_cancel_clue').click(function () {
        $('#shop_info').show();
        $('#clue_info').hide();

        handleClue();
    });

    // 标签相关
    $('#btn_add_tag').click(function () {
        $('#shop_info').hide();
        $('#tag_info').show();
        // getPrivateTags();
        getAllTags();
    });
    $('#btn_save_tag').click(function () {
        $('#shop_info').show();
        $('#tag_info').hide();

        // TODO : 如果输入的标签与已有标签相同，给出提示
        var tag = $.trim($('#new_tag').val());
        if (tag.length != 0) {
            createAndCommitTag(tag);
        } else {
            saveTag();
        }
    });
    $('#btn_cancel_tag').click(function () {
        $('#shop_info').show();
        $('#tag_info').hide();
    });

    $('#btn_save').click(function () {
        finishTask();
    });

    $('.ui.checkbox').checkbox();

    $('.ui.radio.checkbox').checkbox();
}

function initClue() {
    var maininfo_template = Handlebars.compile($('#entry_maininfo_template').html());
    $('#maininfo_template').html(maininfo_template(shopInfo));
    $('#shop_url').html(shopInfo.url);
}

function saveClue() {
    chrome.runtime.sendMessage(
        {
            event: "saveClue",
            source: $('#clue_source input[name="clue"]:checked').next().text(),
            info: shopInfo.corp_name,
            content: $('#clue_content').val(),
            url: shopInfo.url,
            law: $('#law_content').dropdown('get value'),
            other: $('#other_info').val()
        },
        function (resp) {
            console.log(resp.result);
            if ($('#clue_handle').val() != 0) {
                handleClue(resp._id);
            }
        }
    );
}

function handleClue(id) {
    chrome.runtime.sendMessage(
        {
            event: 'getUserInfo'
        },
        function (resp) {
            var region = resp.region;
            chrome.runtime.sendMessage(
                {
                    event: 'getUsersByDepartment',
                    region: region
                },
                function (resp) {
                    console.log(resp.result);
                    $.each(resp.result, function (idx, obj) {
                        if (obj.role == 'business_administrator') {
                            var handle = {
                                '1': 'tipstaff_applyguide_clue',
                                '2': 'tipstaff_applycorrect_clue',
                                '3': '',
                                '4': ''
                            };
                            chrome.runtime.sendMessage(
                                {
                                    event: 'handleClue',
                                    wf_name: handle[$('#clue_handle').val()],
                                    action: 'commit',
                                    clue_id: id,
                                    to_user: obj.username
                                },
                                function (resp) {

                                }
                            )
                        }
                    });
                }
            );
        }
    );
}

function initShopInfo(url) {
    var shopinfo_template = Handlebars.compile($('#entry_shopinfo_template').html());

    chrome.runtime.sendMessage(
        {
            event: "initShop",
            url: window.btoa(url)
        },
        function (resp) {
            shopInfo.shop_type = resp.main_info.shop_type;
            shopInfo._id = resp.main_info._id;
            shopInfo.corp_name = resp.main_info.corp_name;
            shopInfo.shop_name = resp.main_info.shop_name;
            shopInfo.contact_name = resp.main_info.contact_name;
            shopInfo.enroll_addr = resp.main_info.enroll_addr;
            shopInfo.tags = resp.tags;
            $('#shopinfo_template').html(shopinfo_template(resp));
        }
    );
}

function getAllTags() {
    chrome.runtime.sendMessage(
        {
            event: "getAllTags"
        },
        function (resp) {
            var data = resp.result;
            $('#custorm_tags').empty();
            $('#private_tags').empty();
            $('#pre_tags').empty();
            $.each(data, function (idx, obj) {
                var html = "<div class='ui checkbox'><input class='hidden' tabindex='0' type='checkbox' value='"
                    + obj.id + "'><label>" + obj.name + "</label></div>";
                $.each(shopInfo.tags, function (_idx, _obj) {
                    if (_obj == obj.name) {
                        html = "<div class='ui checkbox'><input class='hidden' tabindex='0' type='checkbox' checked='checked'><label>" +
                            obj.name + "</label></div>";
                    }
                });
                if (obj.origin == 'person') {
                    if (obj.region_id != null) {
                        // 自设标签
                        $('#custorm_tags').append(html);
                    } else {
                        // 个人标签
                        $('#private_tags').append(html);
                    }
                } else {
                    // 预设标签
                    $('#pre_tags').append(html);
                }
            });
            $('.ui.checkbox').checkbox();
        }
    );
}

function getPrivateTags() {
    var tag_template = Handlebars.compile($('#entry_tag_template').html());
    chrome.runtime.sendMessage(
        {
            event: "getTags"
        },
        function (resp) {
            $('#tag_template').html(tag_template(resp.result));
        }
    );
}

function saveTag(tag) {
    var data = {'tags': []};
    $('#tag_info input[type="checkbox"]:checked').each(function () {
        if ($(this).next().text() != "自动申请入库") {
            data.tags.push($(this).next().text());
        }
    });
    if (tag != undefined) {
        data.tags.push(tag);
    }
    console.log(data);

    chrome.runtime.sendMessage(
        {
            event: "saveTag",
            type: shopInfo.shop_type,
            id: shopInfo._id,
            url: shopInfo.url,
            data: data
        },
        function (resp) {
            if (resp.status) {

            }
        }
    );
}

function commitTag(tagId) {
    var data = {
        "tag_id": tagId,
        "action": "apply"
    };
    chrome.runtime.sendMessage(
        {
            event: "commitTag",
            data: data
        },
        function (resp) {

        }
    );
}

function createAndCommitTag(tag) {
    chrome.runtime.sendMessage(
        {
            event: "createTag",
            tagName: tag,
            url: shopInfo.url
        },
        function (resp) {
            if (resp.status) {
                saveTag(tag);
                if ($('#auto_commit').is(':checked')) {
                    commitTag(resp.id);
                }
            } else {
                saveTag();
            }
        }
    );
}


function finishTask() {
    var data = {
        'result': 'completed',
        'problem': $('#problem').val()
    };
    chrome.runtime.sendMessage(
        {
            event: "finishTask",
            id: shopInfo._id,
            data: data
        },
        function (resp) {
            console.log(resp.result);
        }
    );
}

$(document).ready(
    function () {
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, function (tabs) {
            initShopInfo(tabs[0].url);
            shopInfo.url = tabs[0].url;
        });

        init();
    }
);
