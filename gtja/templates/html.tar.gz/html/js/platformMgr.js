/**
 * Created by hz on 15-9-2.
 */

var data = null;

function getDetailInfo(index, type, offset, limit, filter, filter_key, sort_key, sort_direct) {
    var data = {
        index: index,
        type: type,
        offset: offset,
        limit: limit,
        filter: filter,
        filter_key: filter_key,
        sort_key: sort_key,
        order: sort_direct
    };

    detail_info_id = {
        0: "#detail-info-ind0",
        1: "#detail-info-ind1",
        2: "#detail-info-ind2",
        3: "#detail-info-ind3",
        4: "#detail-info-ind4"
    };
    detail_info_template = {
        0: detail_info_ind0_template,
        1: detail_info_ind1_template,
        2: detail_info_ind2_template,
        3: detail_info_ind3_template,
        4: detail_info_ind4_template
    };

    function onSuccess(resp, status) {
        var detail_info = null;
        if (index == 2) {
            detail_info = (detail_info_template[index])(resp);
            $(detail_info_id[index]).html(detail_info);
        } else {
            detail_info = (detail_info_template[index])(resp.result);
            $(detail_info_id[index]).html(detail_info);
            var total = resp.total;
            var offset = resp.offset;
            var limit = resp.limit;
            if (total == undefined || total == 0) {
                $(detail_info_id[index]).html(notFoundMessgae);
                return;
            }
            var pagination = $(detail_info_id[index]).parent().nextAll('.ui.my_pagination');
            initUiPaginationData(pagination, total, offset, limit, {
                extra_data1: index,
                extra_data2: type,
                extra_data3: filter,
                extra_data4: filter_key
            });
        }
    }

    function onError(error) {
        $(detail_info_id[index]).html(notFoundMessgae);
    }

    getShopsData(data, onSuccess, onError);
}

//查看详情
function showDetail(ind, index, obj) {
    var id = $(obj).attr('value');
    var type = $(obj).parents('.content').nextAll('.extra-func').children('.dropdown').dropdown('get value');
    getShopDetail(index, type, id, function (resp) {
        if(index == 3) {
            $('#grayshop-info-entry').html(grayshop_info_template([resp]));
            $('#bulletin-info').hide();
            $('#shop-info').hide();
            $('#blackshop-info').hide();
            $('#grayshop-info').show();
        } else if (index == 4) {
            $('#blackshop-info-entry').html(blackshop_info_template([resp]));
            $('#bulletin-info').hide();
            $('#shop-info').hide();
            $('#grayshop-info').hide();
            $('#blackshop-info').show();
        } else {
            $('#grayshop-info').hide();
            $('#blackshop-info').hide();
            $('#bulletin-info').hide();
            $('#shop-info').show();
            $('#shop-info').attr('type', type);
            $('#shop-info').attr('index', index);
            $('#shop-info').attr('shop_id', id);
            var content = shop_info_template([resp]);
            $('#shop-info-entry').html(content);
            if (ind == 0) {
                $('#edit-shop-info').hide();
                $('#deal-shop-commit').hide();
            } else {
                $('#edit-shop-info').show();
                $('#deal-shop-commit').show();
            }
        }
        $('.ui.page.dimmer').dimmer('show');
    });
}

function dismissDetail() {
    $('.ui.page.dimmer').dimmer('hide');
}

function showBulletinDetail(id) {
    $.ajax({
        cache: false,
        url: base_url + '/bulletin/' + id,
        type: 'get',
        success: function (data, status) {
            $('#shop-info').hide();
            $('#grayshop-info').hide();
            $('#blackshop-info').hide();
            $('#bulletin-info').show();
            data.bulletin.replace(/\r\n/gi,"<br/>");
            var content = bulletin_content_template([data]);
            $('#bulletin-info').html(content);
            $('.ui.page.dimmer').dimmer('show');
        },
        error: function (error) {
            console.log(error);
        }
    });
}

//设置平台信息数据
function reset() {
    $("#deal-platform-submit").val(data._id);
    $("#platform-info input[name='register_num']:eq(0)").val(data.register_num);
    $("#platform-info input[name='corp_name']:eq(0)").val(data.corp_name);
    $("#platform-info input[name='retailer_name']:eq(0)").val(data.name);
    $("#retailer_url_a a").html(data.domain);
    $("#retailer_url_a a").attr('href', data.domain);
    $("#retailer_url_input").hide();
    $("#retailer_url_a").show();
    $("#platform-info input[name='domain']:eq(0)").val(data.domain);
    $("#platform-info input[name='icp']:eq(0)").val(data.icp);
    $("#platform-info input[name='isp']:eq(0)").val(data.isp);
    $("#platform-info input[name='running_time']:eq(0)").val(data.running_time);
    $("#platform-info input[name='contact_name']:eq(0)").val(data.contact_name);
    $("#platform-info input[name='phone']:eq(0)").val(data.phone);
    $("#platform-info input[name='email']:eq(0)").val(data.email);
}

//启用编辑
function enable_edit() {
    $('#shop_url_a').hide();
    $('#shop_url_input').show();
    $("#retailer_url_input").show();
    $("#retailer_url_a").hide();
    $(arguments[0] + ' .changeable-input').attr('disabled', false);
    $(arguments[0] + ' .changeable-input').removeClass('input-disabled');
    $(arguments[0] + ' .changeable-input').parent().removeClass('transparent');
    $(arguments[0]).addClass('editing');
    $(arguments[1]).css('display', '');
}

//禁用编辑
function disable_edit() {
    $('#shop_url_a').show();
    $('#shop_url_input').hide();
    $("#retailer_url_input").hide();
    $("#retailer_url_a").show();
    $(arguments[0] + ' .changeable-input').attr('disabled', true);
    $(arguments[0] + ' .changeable-input').addClass('input-disabled');
    $(arguments[0] + ' .changeable-input').parent().addClass('transparent');
    $(arguments[0]).removeClass('editing');
    $(arguments[1]).css('display', 'none');
}

//展开详细信息
function openIndex(ind) {
    //console.log(ind);
    $('.ui.accordion').accordion('open', ind);
}

function initPageContent() {
    function initCommonComponent() {
        /*------初始化----------*/
        $('.ui.accordion').accordion({'exclusive': false}); //允许同时展开多个
        $('.ui.accordion').accordion('setting', 'onOpening', function () {
            getDetailInfo(this.attr('index'), this.nextAll('.extra-func').children('.store-type').dropdown('get value'));
        });
        $('.ui.page.dimmer').dimmer('setting', 'onHide', function () {
            disable_edit('.dimmer-wrap');
        });
        $('.ui.dropdown').dropdown();

        detail_info_ind0_source = $("#detail-info-ind0-template").html();
        detail_info_ind0_template = Handlebars.compile(detail_info_ind0_source);
        detail_info_ind1_source = $("#detail-info-ind1-template").html();
        detail_info_ind1_template = Handlebars.compile(detail_info_ind1_source);
        detail_info_ind2_source = $("#detail-info-ind2-template").html();
        detail_info_ind2_template = Handlebars.compile(detail_info_ind2_source);
        detail_info_ind3_source = $("#detail-info-ind3-template").html();
        detail_info_ind3_template = Handlebars.compile(detail_info_ind3_source);
        detail_info_ind4_source = $("#detail-info-ind4-template").html();
        detail_info_ind4_template = Handlebars.compile(detail_info_ind4_source);


        //切换网店类型
        $('.store-type').change(function (event) {
            var val = $(event.target).val();
            var table = $(event.target).parent().parent().prevAll('.content').children('table');
            var filter_label = $(event.target).parent().nextAll('div').children('.dropdown').children('.text');
            var filter = $(event.target).parent().nextAll('div').children('.dropdown').children('.menu');

            var type = 'corp';
            if ("person" == val) {
                table[0].getElementsByTagName('a')[0].innerHTML = "经营者";
                table[0].getElementsByTagName('a')[1].innerHTML = "身份证号";
                $(table[0].getElementsByTagName('a')[0]).attr("name", "identity");
                $(table[0].getElementsByTagName('a')[1]).attr("name", "real_name");
                $(filter_label).html("经营者");
                $(filter.children()[0]).html("经营者");
                $(filter.children()[1]).html("身份证号");
                $(filter.children()[0]).attr("name", "identity");
                $(filter.children()[1]).attr("name", "real_name");
                type = 'person';
            } else {
                table[0].getElementsByTagName('a')[0].innerHTML = "注册号";
                table[0].getElementsByTagName('a')[1].innerHTML = "企业名称";
                $(table[0].getElementsByTagName('a')[0]).attr("name", "register_num");
                $(table[0].getElementsByTagName('a')[1]).attr("name", "corp_name");
                $(filter_label).html("注册号");
                $(filter.children()[0]).html("注册号");
                $(filter.children()[1]).html("企业名称");
                $(filter.children()[0]).attr("name", "register_num");
                $(filter.children()[1]).attr("name", "corp_name");
            }

            if ($(event.target).parent().parent().prevAll('.content').hasClass('active')) {
                getDetailInfo($(table[0].parentNode).attr('index'), type);
            }
        });

        //切换待处理和已处理
        $('.process-stat').click(function (event) {
            $(event.target).parent().children('span.process-stat').removeClass('active');
            $(event.target).addClass('active');
        });

        /*点击表头进行排序*/
        $(".detail_sort_type").each(function () {
            $(this).click(function () {
                $(this)[0].direct = ($(this)[0].direct == "asc") ? "desc" : "asc";
                var key = $(this)[0].name;
                var direct = $(this)[0].direct;
                var index = $(this).parent().parent().parent().parent().parent().attr('index');
                var val = $($(this).parent().parent().parent().parent().parent().parent().find('select')[0]).val();
                var type = ("自然人网店" == val) ? 'person' : 'corp';

                getDetailInfo(index, type, undefined, undefined, undefined, undefined, key, direct);
            });
        });

        /*文本输入框处理回车键*/
        $(".detail-search").keydown(function (event) {
            if (event.which == "13") {
                var content = $(this).val();
                if (content.length > 0) { //首先判断输入内容长度
                    var index = $(this).parent().parent().prev().attr('index');
                    var val = $(this).parent().prevAll('select').val();
                    var type = ("自然人网店" == val) ? 'person' : 'corp';
                    var filter = $(this).prevAll('.dropdown').children('.menu').children('.active').attr('name');
                    getDetailInfo(index, type, undefined, undefined, filter, content);
                } else {
                    var index = $(this).parent().parent().prev().attr('index');
                    var type = ("自然人网店" == val) ? 'person' : 'corp';
                    getDetailInfo(index, type);
                }
            }
        });
    }

    function initPlatformInfo() {
        $('#deal-platform-info').hide();
        /*-----事件处理函数-----*/
        $('#platform-info').hover(
            function () {       //显示编辑按钮
                $('#edit-platform-info').fadeIn();
            },
            function () {       //隐藏编辑按钮
                $('#edit-platform-info').fadeOut();
            }
        );

        $('#edit-platform-info').click(function () {
            if ($('#platform-info').hasClass('editing')) {
                reset();
                disable_edit('#platform-info', '#deal-platform-info');
            } else {
                enable_edit('#platform-info', '#deal-platform-info');
            }
        });

        $('#edit-shop-info').click(function () {
            if ($('.dimmer-wrap').hasClass('editing')) {
                disable_edit('.dimmer-wrap');
            } else {
                enable_edit('.dimmer-wrap');
            }
        });

        $('#deal-platform-cancel').click(function () {
            reset();
            disable_edit('#platform-info', '#deal-platform-info');
        });

        $('#deal-platform-submit').click(function () {
            var inputs = $("#platform-info input");
            var info = {};
            $.each(inputs, function () {
                info[$(this).attr('name')] = $(this).val();
            });

            function onSuccess(resp) {
                data = resp;
                reset();
                disable_edit('#platform-info', '#deal-platform-info');
            }

            setRetailerInfo($(this).val(), info, onSuccess);
        });

        function onSuccess(resp) {
            data = resp.result[0];
            reset();
        }

        getRetailerInfo(onSuccess);
    }

    function initBulletin() {
        $.ajax({
            cache: false,
            url: base_url + '/bulletin/',
            type: 'get',
            success: function (data, status) {
                var bulletins_source = $("#bulletin-list-template").html();
                var bulletins_template = Handlebars.compile(bulletins_source);

                var bulletin_list = bulletins_template(data);
                $('#bulletin-list').html(bulletin_list);
            },
            error: function (error) {
                //console.log(error);
            }
        });

        bulletin_content_source = $("#bulletin-info-template").html();
        bulletin_content_template = Handlebars.compile(bulletin_content_source);
    }

    function initStatistics() {
        var urlMapper = {
            //已校验
            'corp_0': '/shops/corp/count',
            'person_0': '/shops/person/count',
            //校验失败
            'corp_1': '/shops/abnormal/corp/count',
            'person_1': '/shops/abnormal/person/count',
            //待补报
            'corp_2': '/workflows/count?wf_name=tipstaff_import_shop',
            'person_2': null,
            //灰名单
            'corp_3': '/aic/corp/abnormallist/count',
            'person_3': null,
            //黑名单
            'corp_4': '/aic/corp/blacklist/count',
            'person_4': null,
            //未上报
            'corp_5': null,
            'person_5': null
        };
        var shopNumber = {
            //已校验
            'corp_0': 0,
            'person_0': 0,
            //校验失败
            'corp_1': 0,
            'person_1': 0,
            //待补报
            'corp_2': 0,
            'person_2': 0,
            //灰名单
            'corp_3': 0,
            'person_3': 0,
            //黑名单
            'corp_4': 0,
            'person_4': 0,
            //未上报
            'corp_5': 0,
            'person_5': 0
        };

        var complete = 0;
        var length = Object.getOwnPropertyNames(urlMapper).length;
        $.each(urlMapper, function (name, value) {
            if (value != null) {
                $.ajax({
                    cache: false,
                    url: base_url + value,
                    type: 'get',
                    success: function (data, status) {
                        shopNumber[name] = data.count;
                        if (++complete == length) {
                            var number = {};
                            number.verified = shopNumber['corp_0'] + shopNumber['person_0'];
                            number.verify_fail = shopNumber['corp_1'] + shopNumber['person_1'];
                            number.supplementary = shopNumber['corp_2'] + shopNumber['person_2'];
                            number.graylist = shopNumber['corp_3'] + shopNumber['person_3'];
                            number.blacklist = shopNumber['corp_4'] + shopNumber['person_4'];
                            number.unreport = shopNumber['corp_5'] + shopNumber['person_5'];

                            $('span.verified-num').html(number.verified);
                            $('span.verify-fail-num').html(number.verify_fail);
                            $('span.supplementary-num').html(number.supplementary);
                            $('span.graylist-num').html(number.graylist);
                            $('span.blacklist-num').html(number.blacklist);
                            $('span.unreport-num').html(number.unreport);
                        }

                    },
                    error: function (error) {
                        complete++;
                        console.log(error);
                    }
                });
            } else {
                complete++;
            }
        });


        shop_info_source = $("#shop-info-template").html();
        shop_info_template = Handlebars.compile(shop_info_source);
        grayshop_info_template = Handlebars.compile($("#gray-info-template").html());
        blackshop_info_template = Handlebars.compile($("#black-info-template").html());

        $('#deal-shop-cancel').click(function () {
            $('#shop-info').removeAttr('type');
            $('#shop-info').removeAttr('index');
            $('#shop-info').removeAttr('shop_id');
            dismissDetail();
        });

        $('#gray-shop-cancel').click(function () {
            $('.ui.page.dimmer').dimmer('hide');
        });

        $('#black-shop-cancel').click(function () {
            $('.ui.page.dimmer').dimmer('hide');
        });

        $('#deal-shop-commit').click(function () {
            var type = $('#shop-info').attr('type');
            var index = $('#shop-info').attr('index');
            var id = $('#shop-info').attr('shop_id');
            var inputs = $("#shop-info-entry input");
            var data = {};
            $.each(inputs, function () {
                data[$(this).attr('name')] = $(this).val();
            });

            setShopDetail(index, type, id, data, function (resp) {
                var _id = resp._id;
                var detail_info = (detail_info_template[index])([resp]);
                //$('#' + _id).replaceWith(detail_info);

                $('#' + id).remove();
                $('#shop-info').removeAttr('type');
                $('#shop-info').removeAttr('index');
                $('#shop-info').removeAttr('shop_id');
                dismissDetail();
            });
        });
    }

    initCommonComponent();
    initPlatformInfo();
    initBulletin();
    initStatistics();

    initUiPagination();

    $('.ui.my_pagination span').prev().click(function () {
        uiPaginationPrev($(this).parent(), function (offset, limit, extraData) {
            var index = extraData.data1;
            var type = extraData.data2;
            var filter = extraData.data3;
            var filter_key = extraData.data4;
            getDetailInfo(index, type, offset, limit, filter, filter_key);
        });
    });

    $('.ui.my_pagination span').next().click(function () {
        uiPaginationNext($(this).parent(), function (offset, limit, extraData) {
            var index = extraData.data1;
            var type = extraData.data2;
            var filter = extraData.data3;
            var filter_key = extraData.data4;
            getDetailInfo(index, type, offset, limit, filter, filter_key);
        });
    });

    //$('.ui.my_pagination').each(function() { console.log(this); $(this).hide();});
}

$(document).ready(function () {
    initPageContent();
});
