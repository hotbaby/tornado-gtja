var tabUrl = [
    "aic_cba_resource_mgr.html",
    "aic_cba_task_mgr.html",
    "aic_cba_shop_mgr.html",
    "aic_cba_tags_mgr.html",
    "aic_cba_clue_mgr.html",
    "aic_cba_proof_mgr.html",
    "aic_cba_case_mgr.html",
    "aic_cba_decision_support.html"
];

var initFunctions = new Array();
$(document).ready(function () {
    var count = 0;
    for (var i = 0; i < tabUrl.length; i++) {
        $('.ui.tab').eq(i).load(tabUrl[i], function(response, status, xhr ) {
            count++;
            if(count == tabUrl.length) {
                /*下拉菜单效果*/
                $('.ui.dropdown').dropdown();

                initUiPagination();
                /*各个html的初始化函数调用*/
                $.each(initFunctions, function() {this();});
                $('.ui.checkbox')
                    .checkbox()
                ;
                $('table .select_all').click(function() {selectAllCheckbox(this);});
            }
        });
    }
    $('#header_menu .item').tab({
        context : '#mainBody',
        history : true,
        path : '/aic_cba.html'
    });
});
