/**
 * Created by hz on 15-8-31.
 */

server_host = document.domain;
server_port = "80";
base_url = "http://" + server_host + ":" + server_port + "/api/v1";
notFoundMessgae = "<tr><td colspan='15' style='text-align: center;'>当前类型数据为空</td></tr>";

/*-- 设置输入框获取焦点时，光标在文字的最后面，调用方法$(element).focusEnd(); --*/
$.fn.setCursorPosition = function (position) {
    if (this.lengh == 0) return this;
    return $(this).setSelection(position, position);
};

$.fn.setSelection = function (selectionStart, selectionEnd) {
    if (this.lengh == 0) return this;
    input = this[0];

    if (input.createTextRange) {
        var range = input.createTextRange();
        range.collapse(true);
        range.moveEnd('character', selectionEnd);
        range.moveStart('character', selectionStart);
        range.select();
    } else if (input.setSelectionRange) {
        input.focus();
        input.setSelectionRange(selectionStart, selectionEnd);
    }

    return this;
};

$.fn.focusEnd = function () {
    this.setCursorPosition(this.val().length);
};
/*------ 设置输入框获取焦点结束 -----*/

/*------ 分页插件相关操作函数 start ------*/
function initUiPagination(obj) {
    if (obj == undefined) {
        $(".ui.my_pagination").each(
            function(index, item) {
                if ($(item).children('a').length == 0) {
                    $(item).children('span').before('<a class="prev" href="javascript:void(0)" style="margin-right:10px;"><i class="chevron left icon"></i>上一页</a>');
                    $(item).children('span').after('<a class="next" href="javascript:void(0)" style="margin-left:10px;">下一页<i class="chevron right icon"></i></a>');
                }
                $(item).hide();
            }
        );
    } else {
        if(obj.children('a').length == 0) {
            obj.children('span').before('<a class="prev" href="javascript:void(0)" style="margin-right:10px;"><i class="chevron left icon"></i>上一页</a>');
            obj.children('span').after('<a class="next" href="javascript:void(0)" style="margin-left:10px;">下一页<i class="chevron right icon"></i></a>');
        }

        obj.hide();
    }
}

function initUiPaginationData(pagination, total, offset, limit, extra_data) {
    if (total != undefined && total != 0 && total >= limit ) {
        pagination.show();

        var page_num = Math.ceil(total / limit);
        var current = Math.ceil((offset + 1) / limit);
        setUiPaginationData(pagination, current, limit, page_num, extra_data);
    } else {
        if(total != undefined && limit != 0) {
            var page_num = Math.ceil(total / limit);
            var current = Math.ceil((offset + 1) / limit);
            setUiPaginationData(pagination, current, limit, page_num, extra_data);
        }
        pagination.hide();
    }
}

function setUiPaginationData(pagination, current, limit, page_num, extra_data) {
    pagination.attr({
        'page': current,
        'limit': limit,
        'total': page_num
    });
    //console.log(extra_data);
    pagination.removeAttr('extra_data1');
    pagination.removeAttr('extra_data2');
    pagination.removeAttr('extra_data3');
    pagination.removeAttr('extra_data4');
    if (extra_data != undefined) {
        $.each(extra_data, function (name, value) {
            pagination.attr(name, value);
        });
    }
    pagination.children('span').html(current + '/' + page_num);
}

function uiPaginationPrev(pagination, callback) {
    var page = parseInt($(pagination).attr('page'));
    var limit = parseInt($(pagination).attr('limit'));
    var total = parseInt($(pagination).attr('total'));
    var extraData = {};
    extraData.data1 = $(pagination).attr('extra_data1');
    extraData.data2 = $(pagination).attr('extra_data2');
    extraData.data3 = $(pagination).attr('extra_data3');
    extraData.data4 = $(pagination).attr('extra_data4');

    if (page > 1) {
        page--;
        $(pagination).attr('page', page);
        var offset = (page - 1) * limit;
        if (callback instanceof Function) {
            callback(offset, limit, extraData);
        }
    }
}

function uiPaginationNext(pagination, callback) {
    var page = parseInt($(pagination).attr('page'));
    var limit = parseInt($(pagination).attr('limit'));
    var total = parseInt($(pagination).attr('total'));
    var extraData = {};
    extraData.data1 = $(pagination).attr('extra_data1');
    extraData.data2 = $(pagination).attr('extra_data2');
    extraData.data3 = $(pagination).attr('extra_data3');
    extraData.data4 = $(pagination).attr('extra_data4');

    if (page < total) {
        page++;
        $(pagination).attr('page', page);
        var offset = (page - 1) * limit;
        if (callback instanceof Function) {
            callback(offset, limit, extraData);
        }
    }
}
/*------ 分页插件相关操作函数 end ------*/

/*------用户管理相关操作接口 start------*/
var roleMapper = {
    "system_administrator": '系统管理员',
    "business_administrator": '业务管理员',
    "platform_administrator": '平台管理员',
    "enterprise_administrator": '企业管理员',
    "tipstaff": '执法员',
    "leader": '负责人'
};

var userDetail;
function getUserDetail() {
    $.ajax({
        async: false,
        cache: false,
        url: encodeURI(base_url + '/user/detail', 'UTF-8'),
        type: 'get',
        success: function (data, status) {
            //console.log(data);
            var content = data.realname + ' ' + data.region + ((data.department == null) ? '' : data.department) + ' ' + roleMapper[data.role];
            if ('platform_administrator' == data.role) {
                content = data.realname + ' ' + roleMapper[data.role];
            }
            $('#username').html(content);
            userDetail = data;
        },
        error: function (error) {
            //location.href = 'login.html';
        }
    });
    /*鼠标移上时显示过长的字段——9.15添加*/
    $('#username').mouseover(function () {
        var name1 = $('#username').html();
        //console.log(name1);
        $('#username').attr('title', name1);
    });
}

function getDepartmentsByUser(level, onSuccess, onError) {
    var levelUrlMapper = {
        'upper': 'upper_level',
        'lower': 'lower_level'
    };

    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/user/region?filter=' + levelUrlMapper[level], 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getUsersByDepartment(department, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/user/help?region=' + department, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
function getLowerDepartment(department, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/user/region/lower_level?region=' + department, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function userLogout() {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/user/logout', 'UTF-8'),
        type: 'get',
        success: function (data, status) {
            location.href = 'login.html';
        },
        error: function (error) {
            // 增加提示信息
        }
    });
}
/*------用户管理相关操作接口 end------*/

/*------平台数据相关操作接口 start------*/
function getRetailerInfo(onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + "/retailers", 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function setRetailerInfo(obj, data, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + "/retailers/" + obj, 'UTF-8'),
        data: JSON.stringify(data),
        type: 'PATCH',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function createRetailerInfo(data, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + "/retailers", 'UTF-8'),
        data: JSON.stringify(data),
        type: 'post',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function deleteRetailerInfo(obj, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + "/retailers/" + obj, 'UTF-8'),
        type: 'delete',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/*------平台数据相关操作接口 end------*/

/*------网店数据相关操作接口 start----*/
var pageLimit = 5;

var urlMapper = {
    0: { //已校验
        'corp': '/shops/corp',
        'person': '/shops/person'
    },
    1: { //校验失败
        'corp': '/shops/abnormal/corp',
        'person': '/shops/abnormal/person'
    },
    2: { //待补报
        'corp': '/shops/repay/corp',
        'person': '/shops/repay/person'
    },
    3: { //灰名单
        'corp': '/aic/corp/abnormallist',
        'person': ''
    },
    4: { //黑名单
        'corp': '/aic/corp/blacklist',
        'person': ''
    }
};

function getShopsData(data, onSuccess, onError) {
    var index = data.index;
    var type = data.type;
    var offset = data.offset;
    var limit = data.limit;
    var filter = data.filter;
    var filter_key = data.filter_key;
    var sort_key = data.sort_key;
    var order = data.order;

    //console.log("index: " + index +" type: " + type + " offset: " + offset + " limit: " + limit + " filter: " + filter + " filter_key: " + filter_key + " sort_key: " + sort_key + " order: " + order);

    if(urlMapper[index][type] == '') {
        if (onError instanceof Function) {
            onError('');
        }
        return;
    }

    if (offset == undefined) {
        offset = 0;
    }
    if (limit == undefined) {
        limit = 5;
    }

    var url = base_url + urlMapper[index][type] + '?offset=' + offset + '&limit=' + limit;

    if (filter != undefined) {
        url += '&search_key=' + filter;
    }

    if (filter_key != undefined) {
        url += '&search_value=' + filter_key + '&fuzzy=1';
    }

    if (sort_key != undefined) {
        url += '&sort_key=' + sort_key;
    }

    if (order != undefined) {
        url += '&order=' + order; //1--ASC -1--DESC
    }

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getShopDetail(index, type, id, onSuccess, onError) {
    //console.log("id: " + id);
    var url = "";
    if(index == 2) {
       url =  base_url + '/shops/repay/' + id;
    } else {
       url = base_url + urlMapper[index][type] + '/' + id;
    }
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function setShopDetail(index, type, id, data, onSuccess, onError) {
    var url = base_url + urlMapper[index][type] + '/' + id;
    var method = "patch";
    if(index == 2) {
        url =  base_url + '/shops/repay/' + id;
        data.shop_type=type;
        method = "post";
    }
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        data: JSON.stringify(data),
        type: method,
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function assignShopDomain(method, data, onSuccess, onError) {
    /*method = "level", "protocol", "specify"*/
    var url = base_url + '/match/' + method;
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        data: (data == null) ? "" : JSON.stringify(data),
        type: 'patch',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/*------网店数据相关操作接口 end----*/

/*-----价格异常数据 start -----*/
function getExceptionPriceData(data, onSuccess, onError) {
    var offset = data.offset;
    var limit = data.limit;
    var filter = data.filter;
    var filter_key = data.filter_key;
    var sort_key = data.sort_key;
    var order = data.order;
    if (offset == undefined) {
        offset = 0;
    }
    if (limit == undefined) {
        limit = 5;
    }
    var url = base_url + '/clues/price_ex?offset=' + offset + '&limit=' + limit;

    if (filter != undefined) {
        url += '&search_key=' + filter;
    }

    if (filter_key != undefined) {
        url += '&search_value=' + filter_key;
    }

    if (sort_key != undefined) {
        url += '&sort_key=' + sort_key;
    }

    if (order != undefined) {
        url += '&order=' + order; //1--ASC -1--DESC
    }

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/*-----价格异常数据 end -----*/

/*-----线索数据相关操作结构 start -----*/
function getCluesData(data, onSuccess, onError) {
    var index = data.index;
    var type = data.type;
    var offset = data.offset;
    var limit = data.limit;
    var filter = data.filter;
    var filter_key = data.filter_key;
    var sort_key = data.sort_key;
    var order = data.order;

    if (offset == undefined) {
        offset = 0;
    }
    if (limit == undefined) {
        limit = 5;
    }
    var url = base_url + '/clues?offset=' + offset + '&limit=' + limit;

    if (filter != undefined) {
        url += '&search_key=' + filter;
    }

    if (filter_key != undefined) {
        url += '&search_value=' + filter_key;
    }

    if (sort_key != undefined) {
        url += '&sort_key=' + sort_key;
    }

    if (order != undefined) {
        url += '&order=' + order; //1--ASC -1--DESC
    }

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function createCluesData(data, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/clues', 'UTF-8'),
        type: 'post',
        data: JSON.stringify(data),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function mergeCluesData(data, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/clues', 'UTF-8'),
        type: 'post',
        data: JSON.stringify({
            "action": "commit",
            "wf_name": "tipstaff_merge_clue",
            "data": data
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function removeClues(clueId, toUser, onSuccess, onError) {
    var data = {
        'wf_name' : 'tipstaff_remove_clue',
        'action' : 'commit',
        'to_user' : toUser,
        'data' : {
            'clue_id' : clueId
        }
    };
    $.ajax({
        cache: false,
        url: encodeURI(base_url + '/workflows', 'UTF-8'),
        type: 'post',
        data: JSON.stringify(data),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/*-----线索数据相关操作结构 end -----*/

/*------标签数据相关操作接口 start------*/
var tagUrl = base_url + '/tags';
var tagLibUrl = base_url + '/tag_lib';
function createPrivateTag(tagName, tagDescription, original_url, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(tagUrl, 'UTF-8'),
        type: 'post',
        data: JSON.stringify({
            "name": tagName,
            "description": tagDescription,
            "original_url": original_url
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function deletePrivateTag(tagId, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(tagUrl, 'UTF-8'),
        type: 'delete',
        data: JSON.stringify({
            "id": tagId
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getPrivateTags(data, onSuccess, onError) {
    var offset = data.offset;
    var limit = data.limit;

    if (offset == undefined) {
        offset = 0;
    }
    if (limit == undefined) {
        limit = 5;
    }
    url = tagUrl + '?offset=' + offset + '&limit=' + limit;
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function setPrivateTag(tagId, tagName, tagDescription, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(tagUrl, 'UTF-8'),
        type: 'put',
        data: JSON.stringify({
            "id": tagId,
            "name": tagName,
            "description": tagDescription
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function commitTagToRepo(tagId, action, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(tagLibUrl, 'UTF-8'),
        type: 'post',
        data: JSON.stringify({
            "tag_id": tagId,
            "action": action
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getTagsRepo(offset, limit, onSuccess, onError) {
    if (offset == undefined) {
        offset = 0;
    }

    if (limit == undefined) {
        limit = 5;
    }

    var url = tagLibUrl + '?offset=' + offset + '&limit=' + limit;
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/*------标签数据相关操作接口 end----*/

/* temp start */
function getShopInJurisdict(addr, onSuccess, onError) {
    var url = base_url + '/match/protocol?enroll_addr=' + addr;
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/* temp end */

/*------任务管理相关操作接口 start----*/
var taskUrl = base_url + '/tasks/filter';
function getShop(data, onSuccess, onError) {
    var taskUri = "";
    var url = taskUrl;

    if (data.retailer != undefined) {
        $.each(data.retailer, function (idx, obj) {
            taskUri = taskUri + 'retailer=' + obj + '&';
        });
    }

    if (data.enroll_addr != undefined) {
        $.each(data.enroll_addr, function (idx, obj) {
            taskUri = taskUri + 'enroll_addr=' + obj + '&';
        });
    }

    if (data.region != undefined) {
        $.each(data.region, function (idx, obj) {
            taskUri = taskUri + 'region=' + obj + '&';
        });
    }

    if (data.tag != undefined) {
        $.each(data.tag, function (idx, obj) {
            taskUri = taskUri + 'tag=' + obj + '&';
        });
    }

    var reg = new RegExp('&$');
    //console.log(reg.test(taskUri));
    if (reg.test(taskUri)) {
        taskUri = taskUri.substring(0, taskUri.length - 1);
    }

    if (taskUri.length > 0) {
        url = url + '?' + taskUri;
    }
    //console.log(url);
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

var wfUrl = base_url + '/workflows';
function createWorkflow(taskType, filterData, speicalTarget, targetType, startTime, endTime, description, random, onSuccess, onError) {
    var url = wfUrl;
    if (taskType == "special_task") {
        url = base_url + '/specialtasks';
    }
    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'post',
        data: JSON.stringify({
            "action": "commit",
            "wf_name": taskType,
            "to_user": speicalTarget,
            "data": {
                "task_type" : targetType, //to_dept  to_tipstaff
                "shop_filter": {
                    "query": filterData
                },
                "random" : random,
                "start_time": startTime,
                "end_time": endTime,
                "description": description
            }
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getWorkflow(type, id, offset, limit, tipstaff,  order, sort_key, onSuccess, onError) {
    var url = wfUrl;
    if (type == "special_task") {
        url = base_url + '/specialtasks';
    }
    if (offset == null) {
        offset = 0;
    }

    if (limit == null) {
        limit = 5;
    }

    if (id == null) {
        url = url + '/data?wf_name=' + type +'&data_limit=' + limit + '&data_offset=' + offset;
    } else {
        url = url + '/' + id + '?data_limit=' + limit + '&data_offset=' + offset + "&tipstaff=" + tipstaff;
        if(order != undefined && sort_key != undefined) {
            url = url + "&status_order=" + order;
        }
    }

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function distributeWorkflow(id, target, targetType, startTime, endTime, description, onSuccess, onError) {
    var url = base_url + '/specialtasks/' + id;

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'post',
        data: JSON.stringify({
            "action": "commit",
            "wf_name": "special_task",
            "to_user": target,
            "data": {
                "task_type" : targetType, //to_dept  to_tipstaff
                "start_time": startTime,
                "end_time": endTime
                //"description": description
            }
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getWorkflowStatus(id, onSuccess, onError) {
    $.ajax({
        cache: false,
        url: encodeURI(wfUrl + '/' + id, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getTaskList(onSuccess, onError, id, offset, limit) {
    var url = wfUrl;
    if (offset == undefined) {
        offset = 0;
    }

    if (limit == undefined) {
        limit = 5;
    }

    if (id != undefined) {
        url = url + '/' + id + '?data_offset=' + offset + '&data_limit=' + limit;
    } else {
        url = url + '?wf_name=tipstaff_run_task&data_offset=' + offset + '&data_limit=' + limit;
    }

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function getTaskDataList(onSuccess, onError) {
    var url = wfUrl + '/data?wf_name=tipstaff_run_task';

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'get',
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}

function commitTaskResult(id, onSuccess, onError) {
    var url = wfUrl + '/id';

    $.ajax({
        cache: false,
        url: encodeURI(url, 'UTF-8'),
        type: 'post',
        data: JSON.stringify({
            "action": "commit",
            "data": {"result": "ok"}
        }),
        success: function (resp, status) {
            if (onSuccess instanceof Function) {
                onSuccess(resp, status);
            }
        },
        error: function (error) {
            if (onError instanceof Function) {
                onError(error);
            }
        }
    });
}
/*------任务管理相关操作接口 end----*/

/*------标签编辑相关操作接口 start----*/
function tag_edit(name) {
    var obj = $('#' + name);
    var value = $(obj).val();
    obj.removeAttr("disabled");
    obj.focus();
    obj.focusEnd();
    obj.attr('oldValue', value);
    obj.parent().removeClass('transparent');
    $('#' + name + '_modify').css("visibility", "visible");
    $('#' + name + '_cancel').css("visibility", "visible");
}

function modify_tag(name) {
    var obj = $('#' + name);
    obj.attr("disabled", "disabled");
    obj.parent().addClass('transparent');
    $('#' + name + '_modify').css("visibility", "hidden");
    $('#' + name + '_cancel').css("visibility", "hidden");

    var tagName = obj.val();
    var oldTagName = obj.attr('oldValue');
    //console.log(tagName + " " + oldTagName);
    if (tagName != oldTagName) {
        var tagId = obj.parents('tr').attr('id');
        setPrivateTag(tagId, tagName, "",
            function () {
                obj.removeAttr('oldValue');
            },
            function (error) {
                var oldValue = obj.attr('oldValue');
                obj.val(oldValue);
                obj.removeAttr('oldValue');
            }
        );
    } else {
        obj.removeAttr('oldValue');
    }
    return true;
}

function keydown_tag(obj, e) {
    var keynum = window.event ? e.keyCode : e.which;
    var name = $(obj).attr('id');
    if (keynum == 13) {
        modify_tag(name);
    }
    return true;
}

function cancel_tag(name) {
    var obj = $('#' + name);
    var oldTagName = obj.attr('oldValue');
    $('#' + name).attr("disabled", "disabled");
    $('#' + name).parent().addClass('transparent');
    $('#' + name + '_modify').css("visibility", "hidden");
    $('#' + name + '_cancel').css("visibility", "hidden");
    obj.val(oldTagName);
    obj.removeAttr('oldValue');
}
/*------标签编辑相关操作接口 end----*/

/*------注册Handlebars的自用模板函数 start-----*/
function registerHandlebarFunctions() {
    Handlebars.registerHelper('timeFormat',
        function (object) {
            var time = new Date(object * 1000);

            function add0(m) {
                return (m < 10) ? ('0' + m) : m
            }

            var y = time.getFullYear();
            var m = time.getMonth() + 1;
            var d = time.getDate();
            var h = time.getHours();
            var mm = time.getMinutes();
            var s = time.getSeconds();
            var format = y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm);
            return new Handlebars.SafeString(format);
            //return new Handlebars.SafeString(time.toLocaleString());
        });

    Handlebars.registerHelper("roleFormat",
        function (object) {
            return new Handlebars.SafeString(roleMapper[object]);
        });

    Handlebars.registerHelper("tagStatus",
        function (object) {
            var statusMapper = {
                "out": "未入库",
                "apply": "申请入库",
                "refuse": "拒绝入库",
                "in": "已入库"
            };
            return new Handlebars.SafeString(statusMapper[object]);
        });

    Handlebars.registerHelper("index",
        function (object) {
            return new Handlebars.SafeString(object + 1);
        });

    Handlebars.registerHelper("taskStatus",
        function (object) {
            var statusMapper = {
                "progressing": "进行中",
                "completed": "已完成",
                "pending": "待处理",
                "assigned": "已处理"
            };
            return new Handlebars.SafeString(statusMapper[object]);
        });

    Handlebars.registerHelper("taskType",
        function (object) {
            var typeMapper = {
                "special_task": "专项任务",
                "normal_task": "日常任务"
            };
            return new Handlebars.SafeString(typeMapper[object]);
        });

    Handlebars.registerHelper("clueStatus",
        function (object) {
            var typeMapper = {
                0: "未处理",
                1: "待审批",
                2: "通过",
                3: "未通过"
            };
            if (object.due_handle!=undefined) {
                return new Handlebars.SafeString(object.due_handle + " " + typeMapper[object.status]);
            } else {
                return new Handlebars.SafeString(typeMapper[object.status]);
            }
        });
}

/*------注册Handlebars的自用模板函数 end-----*/

function setCheckBoxClick(owner, callback) {
    //先清除绑定,避免多次调用
    var firstTd =$(owner + ' tr').find('td:first');

    firstTd.unbind('click');
    $(owner + ' tr .ui.checkbox').unbind('click');

    firstTd.click(
        function (event) {
            if (event.target.hasAttribute('href') || $(event.target).hasClass('button') || $(event.target).hasClass('input')) {
                return true;
            }

            var checkbox = $(this).find('.ui.checkbox');
            $(checkbox).checkbox('toggle');

            if (callback instanceof Function) {
                callback();
            }
        }
    );

    $(owner + ' tr .ui.checkbox').click(
        function () {
            $(this).checkbox('toggle');
            if (callback instanceof Function) {
                callback();
            }
            return true;
        }
    );
}

function doCaseAjaxPost(wf, action, flowInfo, caseid, callback, toUser){
    if (toUser){
        var workFlow = {
            wf_name : wf,
        };

        workFlow.action  = action;
        workFlow.data    = flowInfo;
        if (action == 'back'){
            workFlow.msg = toUser;
        }else{
            workFlow.to_user = toUser;
        }

        $.ajax({
            cache : false,
            url   : base_url + '/workflows/' + caseid,
            type  : 'post',
            data  : JSON.stringify(workFlow),
            success: function (data, status){
                callback();
            },
            error: function (error) {
            }
        });
    }else{
        $.ajax({
            cache : false,
            url   : encodeURI(base_url + '/user/help?region=' + userDetail.region,'UTF-8'),
            type  : 'get',
            success: function(data, status){
                var workFlow = {
                    wf_name : wf,
                };

                workFlow.action = action;
                workFlow.data   = flowInfo;
                for (var i = 0; i < data.result.length; i++){
                   if (data.result[i].role == 'business_administrator'){
                        workFlow.to_user =  data.result[i].username;
                        break;
                    }
                }

                $.ajax({
                    cache : false,
                    url   : base_url + '/workflows/' + caseid,
                    type  : 'post',
                    data  : JSON.stringify(workFlow),
                    success: function (data, status){
                        if(callback)
                            callback();
                    },
                    error: function (error) {
                    }
                });
            },
            error: function (error) {
            }
        });
    }
}

function selectAllCheckbox(obj, callback) {
    var table = $(obj).parents('table')[0];
    //console.log($(table).find(".ui.checkbox"));
    var id = $(table).children('tbody').attr('id');
    $(table).find(".ui.checkbox").checkbox('check');
    if (selectAllCallback[id]) {
        selectAllCallback[id]();
    }
}

var selectAllCallback = {};
function registerSelectAll(id, callback) {
    //console.log(obj);
    selectAllCallback[id] = callback;
    //console.log(selectAllCallback);
}

$(document).ready(function () {
    registerHandlebarFunctions();
    $('#logout').click(function () {
        userLogout();
    });
    getUserDetail();
});
