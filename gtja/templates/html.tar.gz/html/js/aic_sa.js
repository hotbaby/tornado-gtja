/**
 * Created by Roy on 2015/9/8.
 */
function aicSaMgr() {
    var template = Handlebars.compile($('#entry_user_template').html());
    var userAjaxUrl = base_url + '/user';
    var roleAjaxUrl = userAjaxUrl + '/role';

    function getRoleList() {
        $.ajax({
            cache: false,
            url: roleAjaxUrl,
            type: 'get',
            success: function (data, status) {
                console.log(data);
                var roles = data.result;
                $.each(roles, function () {
                    $('#roles_select').append("<option value='" + this + "'>" + roleMapper[this] + "</option>");
                });
            },
            error: function (error) {
            }
        });
    }

    function getUserList() {
        $.ajax({
            cache: false,
            url: userAjaxUrl,
            type: 'get',
            success: function (data, status) {
                console.log(data.result);
                $('#user_template').html(template(data.result));
            },
            error: function (error) {
            }
        });
    }

    function createUser(user) {
        $.ajax({
            cache: false,
            url: userAjaxUrl,
            type: 'post',
            data: JSON.stringify(user),
            success: function (data, status) {
                user.id = data.id;
                $('#user_template').append(template([user]));
                $('#create_user').dimmer('hide');
            },
            error: function (error) {
                // 增加提示信息
            }
        });
    }

    function deleteUser() {
        $("#user_template input[type=checkbox]:checked").each(function () {
            var id = $(this).val();
            $.ajax({
                cache: false,
                url: userAjaxUrl,
                type: 'delete',
                data: JSON.stringify({'id': id}),
                success: function (data, status) {
                    console.log("delete " + id);
                    $('tr#' + id).remove();
                },
                error: function (error) {
                    // 增加提示信息
                }
            });
        });
    }

    function resetData() {
        $('.no-border-table input').each(function() {
           $(this).val('');
        });
    }

    function initEventHandler() {
        //新建用户按钮
        $('#create_btn').click(function () {
            resetData();
            $('#create_user').dimmer('show');
        });

        //删除用户按钮
        $('#del_btn').click(function () {
            deleteUser();
        });

        //新建用户 取消按钮
        $('#create_user_cancel').click(function () {
            $('#create_user').dimmer('hide');
        });

        //新建用户 确定按钮
        $('#create_user_commit').click(function () {
            var user = {
                username: $(".no-border-table input[name='username']").val(),
                password: $(".no-border-table input[name='password']").val(),
                realname: $(".no-border-table input[name='realname']").val(),
                region: $(".no-border-table input[name='region']").val(),
                department: $(".no-border-table input[name='department']").val(),
                role: $(".no-border-table select").val(),
                phone_number: $(".no-border-table input[name='phone_number']").val(),
                email_address: $(".no-border-table input[name='email_address']").val(),
            };
            createUser(user);
        });

        //选择平台管理员时不显示区域与部门输入框
        $('#roles_select').change(function () {
            if ('platform_administrator' == $('#roles_select').val()) {
                $(".no-border-table input[name='region']").parents('tr').hide();
                $(".no-border-table input[name='department']").parents('tr').hide();
            } else {
                $(".no-border-table input[name='region']").parents('tr').show();
                $(".no-border-table input[name='department']").parents('tr').show();
            }
        });
    }

    function init() {
        getRoleList();
        getUserList();
        initEventHandler();
    }

    init();
}

$(document).ready(function () {
    aicSaMgr();
})
