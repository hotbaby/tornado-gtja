var tabUrl = [
    "aic_dba_resource_mgr.html",
    "aic_dba_task_mgr.html",
    "aic_dba_shop_mgr.html",
    "aic_dba_tags_mgr.html",
    "aic_dba_clue_mgr.html",
    "aic_dba_proof_mgr.html",
    "aic_dba_case_mgr.html"
];

var initFunctions = [];
$(document).ready(function () {
    var count = 0;
    for (var i = 0; i < tabUrl.length; i++){
        $('.ui.tab').eq(i).load(tabUrl[i], function() {
            if(++count == tabUrl.length) {
                /*下拉菜单效果*/
                $('.ui.dropdown').dropdown();
                initUiPagination();
                /*各个html的初始化函数调用*/
                $.each(initFunctions, function() {this();});

                $('.ui.checkbox')
                    .checkbox()
                ;
                $('table .select_all').click(function() {selectAllCheckbox(this);});
            }
        });
    }
    $('.menu .item').tab({
			context : '#mainBody',
			history : true,
			path : '/aic_dba.html'
			});

});
