var tabUrl = [
    "aic_dba_task_mgr.html",
    "aic_cba_shop_mgr.html",
    "aic_iba_tags_mgr.html",
    "aic_iba_clue_mgr.html",
    "aic_iba_case_mgr.html"
];

var initFunctions = new Array();
$(document).ready(function () {
    var count = 0;
    for (var i = 0; i < tabUrl.length; i++){
        $('.ui.tab').eq(i).load(tabUrl[i], function(response, status, xhr ) {
            if(++count == tabUrl.length) {
                /*下拉菜单效果*/
                $('.ui.dropdown').dropdown();
                initUiPagination();
                /*各个html的初始化函数调用*/
                $.each(initFunctions, function() {this();});

                $('.ui.checkbox')
                    .checkbox()
                ;
            }
        });
    }
    $('.menu .item').tab({
        context : '#mainBody',
        history : true,
        path : '/aic_iba.html'
    });
});
